@echo off
cd /d "%~dp0"
start "" "%~dp0MarioKartCS.exe" --client
