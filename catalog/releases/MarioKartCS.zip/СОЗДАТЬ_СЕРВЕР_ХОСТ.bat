@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo Запуск Mario Kart C# в режиме СЕРВЕР (ХОСТ)...
start "" "%~dp0MarioKartCS.exe" --host
