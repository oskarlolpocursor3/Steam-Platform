@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo Запуск Mario Kart C# в режиме КЛИЕНТ (ПОДКЛЮЧЕНИЕ)...
echo Целевой IP берется из файла ip.txt или автопоиском по Wi-Fi
start "" "%~dp0MarioKartCS.exe" --client
